<?php

if (!extension_loaded('zbarcode')) {
	die("Skip.");
}

?>